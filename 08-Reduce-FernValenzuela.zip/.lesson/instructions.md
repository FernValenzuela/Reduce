# Instructions  

Log out the average daily wind speed for April.